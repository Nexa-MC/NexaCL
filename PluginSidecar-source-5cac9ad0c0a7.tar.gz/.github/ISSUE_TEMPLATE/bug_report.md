---
name: Bug report
about: Report reproducible behavior
---

## Environment

## Steps and expected behavior

## Actual behavior

## Redacted logs
