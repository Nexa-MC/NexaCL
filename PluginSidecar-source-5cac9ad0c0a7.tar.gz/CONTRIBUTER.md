# Contributor guide

See [CONTRIBUTING.md](CONTRIBUTING.md) / [简体中文](CONTRIBUTING.zh-CN.md). This compatibility entry keeps the contributor guide easy to find.
