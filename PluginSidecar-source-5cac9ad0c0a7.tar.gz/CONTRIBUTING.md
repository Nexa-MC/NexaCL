# Contributing

[简体中文](CONTRIBUTING.zh-CN.md)

Open an issue for a bug or a focused pull request for a change. Explain the behavior, compatibility impact and verification performed. Follow the README build commands before submitting. Keep source, documentation and tests in the same change when they describe one behavior.

Public contracts are experimental. Document boundary changes in `docs/architecture.md` first. Keep Host protocol compatibility explicit; do not invent message IDs without checking the upstream protocol. Do not add private launcher dependencies or credentials.

Use conventional commit messages. Do not commit generated builds, downloaded SDKs, binaries, keys or real account data. Contributions are under Apache-2.0.
