# WebAssembly guest SDK

The production code profile is `nexa-wasm-1`: one WebAssembly module with no
imports. All effects go through negotiated public Host capabilities. The managed
SDK is the contract/adapter SDK; ordinary CLR plugin DLLs are trusted development
only.

## Build the C example

Use Clang with the WebAssembly target and `wasm-ld` (or the official WASI SDK's
Clang; the build explicitly selects `wasm32-unknown-unknown` and links no WASI):

```sh
python eng/generate_abi100.py --verify
python eng/build_wasm_sample.py --clang /path/to/clang
NEXA_WASM_SAMPLE=artifacts/wasm-sample/plugin.zip dotnet run --project tests/PluginSidecar.Tests -c Release
dotnet publish tests/PluginSidecar.AotSmoke -c Release -r linux-x64 -p:PublishAot=true -o artifacts/aot-smoke
NEXA_WASM_SAMPLE=artifacts/wasm-sample/plugin.zip ./artifacts/aot-smoke/PluginSidecar.AotSmoke
```

`sdk/wasm/include/nexa/guest.h` supplies bounded value views, field access,
writers, continuation calls and lifecycle completion. `abi100_ids.h` is generated
from the same operation catalog as the C# SDK. It contains local method numbers,
not Sidecar transport opcodes. `samples/WasmHello/plugin.c` registers a definition
during Initialize, awaits the Host reply, and propagates registration failure.
The test Host explicitly installs its message schema policy and reads the
published definition; no arbitrary consumer is inferred from registration.

The ZIP is an unsigned **developer artifact**. Production acquisition must
authenticate its bytes through Market and the protected Host identity before
`VerifiedPluginPackage.Parse` is called. Never expose that trusted parsing method
as an unsigned user install route. Tests label development trust explicitly.

## Execution and values

The module exports `memory`, `nexa_alloc(i32)->i32`, and
`nexa_resume(i32,i32)->i64`. The runtime copies the encoded input to the allocated
address, resumes the guest and copies its reply. The result's high 32 bits are
the reply address; the low 32 bits are its length. Allocation and resume share
one fuel allowance. Borrowed views must not survive a resume call. The example
uses 64 KiB buffers; the runtime permits up to 4 MiB per encoded value.

The closed binary codec starts with little-endian UInt32 version `1`:

| Tag | Value |
| --- | --- |
| 0 | Null |
| 1 | Boolean byte, exactly 0 or 1 |
| 2, 3, 4 | Little-endian Int64, UInt64, finite Float64 |
| 5, 6 | Int32 byte length followed by strict UTF-8 or raw bytes |
| 7 | Int32 count followed by values |
| 8 | Int32 count followed by UTF-8 keys (length + bytes) and values |

Limits: 32 levels, 16,384 value nodes, 65,536 characters per string, 4 MiB total.
Negative lengths, duplicate keys, invalid UTF-8 and trailing bytes are rejected
by the runtime. Canonical Host encoding sorts keys ordinally. UUIDs are `D`
strings and timestamps are invariant `O` strings. This is the guest payload,
not a new IPC frame.

Lifecycle input contains `kind=callback`, `phase`, `pluginId`, `loadInstanceId`
and `correlationId`. Output is either:

- `kind=complete`, `value={success: bool, code?: string}`;
- `kind=invoke`, `contract`, `method`, `arguments`, optional `operationId`,
  `idempotencyKey` and `expectedRevision`.

An invoke suspends guest execution while the Host runs asynchronously. The next
input is `kind=reply`, `success`, `value` and structured `error`. Actual identity,
stage, scope and remaining deadline come from the Host. Guests cannot override
these by adding fields. Mutation keys are bound to their inputs; unknown outcomes
must remain explicit.

## Static content

`nexa-content-1` uses `declarativeEntryPath` and no code entry. Its payload is
`AbiValueBinary.Encode(DeclarativeContentPack.Write(pack))`, with
`pack.Schema = Abi100Schemas.DeclarativeContentPack`. The signed manifest must
request `nexa.definitions.write` and require `nexa.definitions` version 1.
`nexa-wasm-1` may include the same entry beside its code. Static and code
registration share context, validation, rollback and group commit.

Schema fingerprints include each model's transitive model/enum closure and
codec/scalar contract version. `Abi100Schemas.Validate` uses static readers and
checks exact ID/version/digest. Custom business schemas still require a trusted
schema policy or a future validated dynamic schema implementation.

## Complete typed bindings

Include `nexa/abi100.h` to use the generated C API. It contains 342 current
operations plus 22 compatibility operations under `nx_Legacy_*`. Each model has
`nx_Type_read`, named field accessors and `nx_Type_write`; arrays have typed
`_count`, `_at`, `_write`, and nullable wrappers have `_has_value`, `_value`,
`_none`, `_some`. Enum values have named C constants and exact wire-name codecs.
Models are borrowed byte views; builders append into caller-owned buffers.
Use separate argument and continuation-output buffers to avoid overwriting an
argument while serializing a call. The example demonstrates this ownership.

`nx_Group_Method(writer, request, options)` writes a continuation.
`nx_Group_Method_result(reply, &result)` decodes a successful typed result or
returns false and clears the output. `nx_reply_error(reply)` preserves the full
structured Host error. No automatic fallback, mutation retry or permission grant
occurs. Initialize options with `{0}` and set named fields:

- `operation_id`: optional UUID; the runner assigns one when absent;
- `idempotency_key`: required for catalog mutation operations;
- `expected_revision`: optional optimistic concurrency token;
- `experiment_id`: explicit negotiated experiment, never a stable-call fallback;
- `budget_milliseconds`: optional positive duration up to 300,000 ms. Zero omits
  it. The adapter forwards the smaller requested/remaining callback budget.

`nx_operation_count/at` provide operation metadata. `nx_schema_Type` writes the
same schema reference/fingerprint as `Abi100Schemas.Type` in C#.
`nx_has_capability/permission/experiment` inspect the negotiated snapshot, not
live authorization. A positive result cannot override a revoked grant.

## Typed callbacks

C# authors can use `ICallbacksV1.Register<TInput,TOutput>` from `TypedCallbacks`.
The lease exposes the callback handle and releases it exactly once on Dispose.
Input/output use static codecs, malformed input never reaches the handler, and
structured handler failures are preserved. Registration is inert; a separate
ABI subscription/provider/action registration connects the handler to business
work.

The execution adapter's `IPluginInvocationV1.InvokeHandler` accepts a trusted
Host-supplied context, handler ID, input and invocation scope. Wasm receives
`kind=handler`, `handler`, `input`, `invocationId`, `correlationId`, `causationId`,
remaining `budgetMilliseconds`, and negotiated `abi` metadata. Use
`nx_handler_id/input` and return `nx_handler_success` or `nx_handler_error`.
Handler failures may supply code, message key, parameters and details; identity
and correlation are assigned by the adapter. Normal ABI continuations may be
issued before returning the handler result. Calls before activation, after stop,
or with a foreign context/instance are rejected. Stopping cancels in-flight
business callbacks. This port does not authorize arbitrary external dispatch;
the embedding Host still owns service/event scheduling and target authorization.

## Verification and distribution

`eng/build_wasm_sample.py` builds the example, every generated binding, a callback
fixture and malformed-codec fixture. Set the four `NEXA_WASM_*` variables used in
CI to enable those checks. The suite exercises all 364 operations for success and
failure, 293 model/collection shapes, typed callbacks, Unicode/NUL/exact 64-bit
values and malformed data rejection. Fixture Host replies prove SDK contract
behavior, not the availability of real launcher features. CI repeats these tests
inside a NativeAOT executable on Windows, Linux and macOS.

`eng/package_sdk.py` creates a reproducible standalone header/schema/example ZIP
with file digests. It is a developer SDK artifact, not a signed plugin package.
The C# NuGet package also contains the schemas and C headers. The additive
`IPluginInvocationV1` interface preserves existing Bootstrap assembly identity;
older entries can still implement only the original Bootstrap interface.

## Runnable workflow example

`samples/WasmWorkflow/plugin.c` uses generated schema fingerprints and builders to
register an action, a persistent queued workflow, an interval schedule and cleanup.
Its Initialize callback chains four asynchronous Host replies; Activated starts a
workflow, and handler 1 returns a typed TextResult. Handler 2 is the cleanup path.
Borrowed model views are never retained across a Host continuation.

`eng/build_wasm_sample.py` builds `workflow.wasm` and a deterministic developer
`workflow.zip` alongside the simple definition example. These unsigned ZIPs are
explicit test/development input, not Market grants. Both managed and NativeAOT
suites load the real package, wait for the activation run, manually trigger the
schedule and verify the compiled cleanup after business callbacks are stopped.
The standalone C/Wasm SDK archive includes both example sources.
