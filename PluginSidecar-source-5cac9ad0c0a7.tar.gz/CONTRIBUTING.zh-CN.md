# 贡献指南

[English](CONTRIBUTING.md)

通过 issue 报告问题，或提交范围明确的 PR。说明行为变化、兼容影响和验证结果，提交前执行 README 中的构建检查。行为、文档和相关测试应同时更新。

契约目前为实验状态。修改架构边界前先更新 `docs/architecture.md`；对照上游协议后再定义消息 ID。不得引入启动器私有实现依赖、凭据、构建产物或真实账户数据。提交使用 conventional commits，贡献采用 Apache-2.0。
